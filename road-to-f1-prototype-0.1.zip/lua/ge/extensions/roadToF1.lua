-- Road to F1: manually loaded experimental BeamNG GE extension.
-- No F1 25 assets are included or loaded in this prototype.
local M = {}
local tiers = {
  ["f4"] = {id = "f4", name = "Formula 4", promotion = "f3", baseRepairMultiplier = 0.35, minimumTrust = 40},
  ["f3"] = {id = "f3", name = "Formula 3", promotion = "f2", baseRepairMultiplier = 0.55, minimumTrust = 50},
  ["f2"] = {id = "f2", name = "Formula 2", promotion = "f1", baseRepairMultiplier = 0.8, minimumTrust = 65},
  ["f1"] = {id = "f1", name = "Formula 1", promotion = nil, baseRepairMultiplier = 1.0, minimumTrust = 75},
}
local rules = {
  ["clean_finish"] = {id = "clean_finish", trustDelta = 5, sponsorDelta = 1500, trigger = "race_finished_clean"},
  ["minor_crash"] = {id = "minor_crash", trustDelta = -6, sponsorDelta = -1000, trigger = "damage_minor"},
  ["major_crash"] = {id = "major_crash", trustDelta = -30, sponsorDelta = -15000, trigger = "damage_major"},
  ["demotion"] = {id = "demotion", trustDelta = 0, sponsorDelta = 0, trigger = "trust_below_tier_minimum"},
}
local order = {"f4", "f3", "f2", "f1"}
local savePath = 'settings/roadToF1Career.json'
local state = {tier='f4', trust=60, funds=20000, points=0, races=0}
local function clamp(x, lo, hi) return math.max(lo, math.min(hi, x)) end
local function tierIndex(id)
  for i, value in ipairs(order) do if value == id then return i end end
  return 1
end
local function persist()
  if type(writeJsonFile) ~= 'function' then
    log('W', 'roadToF1', 'writeJsonFile unavailable: progress not saved')
    return false
  end
  return pcall(writeJsonFile, savePath, state, true)
end
local function restore()
  if type(readJsonFile) ~= 'function' then return end
  local ok, saved = pcall(readJsonFile, savePath)
  if ok and type(saved) == 'table' and tiers[saved.tier] then
    state.tier = saved.tier
    state.trust = clamp(tonumber(saved.trust) or 60, 0, 100)
    state.funds = math.max(0, tonumber(saved.funds) or 20000)
    state.points = math.max(0, tonumber(saved.points) or 0)
    state.races = math.max(0, tonumber(saved.races) or 0)
  end
end
local function announce(msg)
  log('I', 'roadToF1', msg)
  if type(guihooks) == 'table' and type(guihooks.trigger) == 'function' then
    guihooks.trigger('toastrMsg', {type='info', title='Road to F1', msg=msg})
  end
end
function M.getStatus()
  return {tier=state.tier, trust=state.trust, funds=state.funds, points=state.points, races=state.races}
end
function M.showStatus()
  announce(string.format('%s | Trust %d | Funds %d | Points %d | Races %d', state.tier:upper(), state.trust, state.funds, state.points, state.races))
end
-- Manual test entrypoint: not wired to real race or damage events yet.
function M.recordTestEvent(eventId, points)
  local rule = rules[eventId]
  if not rule or eventId == 'demotion' then return false, 'unknown event' end
  state.trust = clamp(state.trust + rule.trustDelta, 0, 100)
  state.funds = math.max(0, state.funds + rule.sponsorDelta)
  state.points = state.points + math.max(0, tonumber(points) or 0)
  state.races = state.races + (eventId == 'clean_finish' and 1 or 0)
  local index = tierIndex(state.tier)
  if state.trust < tiers[state.tier].minimumTrust and index > 1 then
    state.tier = order[index-1]
    state.points = 0
    announce('Seat lost: demoted to ' .. state.tier:upper())
  elseif state.points >= 30 and state.trust >= 75 and index < #order then
    state.tier = order[index+1]
    state.points = 0
    announce('Promoted to ' .. state.tier:upper())
  end
  persist()
  M.showStatus()
  return true
end
function M.onExtensionLoaded()
  restore()
  announce('Career prototype loaded. Call extensions.roadToF1.showStatus()')
end
function M.onSaveCurrentSaveSlot() persist() end
return M

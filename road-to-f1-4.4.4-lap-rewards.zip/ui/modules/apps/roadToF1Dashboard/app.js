angular.module('beamng.apps').directive('roadToF1Dashboard', [function () {
  return {
    restrict: 'EA', replace: true,
    templateUrl: '/ui/modules/apps/roadToF1Dashboard/app.html',
    scope: true,
    link: function (scope) {
      // Some BeamNG UI builds do not load an app's app.css automatically.
      // Inject a namespaced stylesheet so the overlay stays readable.
      var cssId='rtf421-dashboard-styles';
      if (!document.getElementById(cssId)) {
        var link=document.createElement('link'); link.id=cssId; link.rel='stylesheet';
        link.href='/ui/modules/apps/roadToF1Dashboard/app.css';
        document.head.appendChild(link);
      }
      scope.data=null; scope.tab='timing'; scope.selectedSeries='f4'; scope.seriesOpen=false; scope.raceLaps=5;
      scope.actionStatus='Ready — controls will report success or errors here.';
      var loadBusy=false;
      var valid={gate:1,startTiming:1,stopTiming:1,submitTiming:1,startWeekend:1,startRace:1,raceDistance:1,pitRepair:1,towToPits:1,wingDetached:1,chooseSponsor:1,loadSeries:1,previewSeries:1,refresh:1};
      scope.command=function(name,arg){
        if(name==='loadSeries' && loadBusy){scope.actionStatus='Vehicle switch already requested. Wait for completion.';return;}
        if(!valid[name])return;
        if(name==='chooseSponsor'){
          if(['localgarage','tracktech','velocity'].indexOf(arg)===-1){scope.actionStatus='Invalid sponsor';return;}
        }else if(name==='loadSeries'||name==='previewSeries'){
          if(['f4','f3','f2','f1'].indexOf(arg)===-1){scope.actionStatus='Select a valid series';return;}
        }else if(name==='raceDistance'){
          arg=Math.floor(Number(arg));
          if(!isFinite(arg)||arg<2||arg>50){scope.actionStatus='Race laps must be 2–50';return;}
        }else{arg=null;}
        var encoded=arg===null?'nil':(typeof arg==='number'?String(arg):JSON.stringify(arg));
        var code='if extensions.roadToF1 then extensions.roadToF1.dashboardCommand('+JSON.stringify(name)+','+encoded+') end';
        scope.actionStatus='Sending GE Lua: '+name+'…';
        // engineLua runs in GE Lua; engineScript runs TorqueScript and cannot access extensions.
        // The callback is an explicit acknowledgement; UI events alone may not reach this app scope.
        try {
          var api = window.bngApi || (typeof bngApi !== 'undefined' ? bngApi : null);
          if (!api || typeof api.engineLua !== 'function') {
            scope.actionStatus='GE Lua bridge unavailable (window.bngApi.engineLua missing)';
            return;
          }
          if(name==='loadSeries') loadBusy=true;
          api.engineLua(code);
          scope.actionStatus='Sent '+name+'; waiting for game confirmation...';
        } catch(e) { scope.actionStatus='Command failed: '+String(e); }

      };
      scope.setTab=function(t){scope.tab=t;}; scope.pickSeries=function(t){scope.selectedSeries=t;scope.seriesOpen=false;};
      scope.time=function(v){if(typeof v!=='number'||!isFinite(v)||v<=0)return '--:--.---';var m=Math.floor(v/60),s=v-m*60;return m+':'+(s<10?'0':'')+s.toFixed(3);};
      scope.money=function(v){return '£'+Math.round(v||0).toLocaleString('en-GB');};
      var l1=scope.$on('RoadToF1Dashboard',function(e,d){scope.data=d;});
      var l2=scope.$on('RoadToF1CommandResult',function(e,d){if(d.action==='loadSeries')loadBusy=false;scope.actionStatus=(d.ok?'OK: ':'Error: ')+d.action+(d.detail?' — '+d.detail:'');});
      scope.$on('$destroy',function(){l1();l2();});
    }
  };
}]);

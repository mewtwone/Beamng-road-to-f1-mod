Road to F1 4.4.4 — lap rewards and dashboard earnings tracker

Valid timed laps: under 60s = GBP 200; 60–120s inclusive = GBP 100; over 120s = GBP 0. Damage does not affect payout. Existing minimum lap validity of 30 seconds remains. Five consecutive damage-free laps still award +2 trust.

The Timing tab displays last lap payout and session lap earnings. All other career systems are retained from 4.4.3.

Install only one Road to F1 ZIP at a time. Back up career JSON files first.

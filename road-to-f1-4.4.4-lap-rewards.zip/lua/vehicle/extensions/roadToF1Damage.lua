-- Road to F1 0.5: damageTracker callback telemetry, diagnostic only.
local M = {}
local registered = false
local seen = 0
local MAX_ITEMS = 24
local function clean(s)
  return type(s) == 'string' and s:sub(1,64):match('^[%w_%-]+$') and s or nil
end
local function scalar(v)
  if type(v) == 'boolean' then return v end
  if type(v) == 'number' and v == v and v > -1e9 and v < 1e9 then return v end
end
local function send(delta)
  if not obj or not obj.queueGameEngineLua then return end
  local id = tonumber(obj:getId())
  if not id then return end
  local result, count = {}, 0
  if type(delta) == 'table' then
    for group, values in pairs(delta) do
      if clean(group) and type(values) == 'table' then
        for name, value in pairs(values) do
          local k, v = clean(name), scalar(value)
          if k and v ~= nil and count < MAX_ITEMS then
            result[#result+1] = {group=group, name=k, value=v}
            count = count + 1
          end
        end
      end
    end
  end
  if count == 0 then return end
  obj:queueGameEngineLua(string.format('if extensions.roadToF1 then extensions.roadToF1.receiveDamageDelta(%d,%s) end', id, serialize(result)))
end
local function onDamage(_, delta) send(delta) end
function M.start()
  if registered then return true end
  if type(damageTracker) ~= 'table' or type(damageTracker.registerDamageUpdateCallback) ~= 'function' then
    log('W', 'roadToF1Damage', 'damage callback unavailable')
    return false
  end
  damageTracker.registerDamageUpdateCallback(onDamage)
  registered = true
  log('I', 'roadToF1Damage', 'damage callback registered')
  return true
end
function M.onReset() registered = false; M.start() end
return M

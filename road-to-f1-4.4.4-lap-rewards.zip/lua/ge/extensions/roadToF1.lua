-- Road to F1: manually loaded experimental BeamNG GE extension.
-- No F1 25 assets are included or loaded in this prototype.
local M = {}
local tiers = {
  ["f4"] = {id = "f4", name = "Formula 4", promotion = "f3", baseRepairMultiplier = 0.35, minimumTrust = 40},
  ["f3"] = {id = "f3", name = "Formula 3", promotion = "f2", baseRepairMultiplier = 0.55, minimumTrust = 50},
  ["f2"] = {id = "f2", name = "Formula 2", promotion = "f1", baseRepairMultiplier = 0.8, minimumTrust = 65},
  ["f1"] = {id = "f1", name = "Formula 1", promotion = nil, baseRepairMultiplier = 1.0, minimumTrust = 75},
}
local rules = {
  ["clean_finish"] = {id = "clean_finish", trustDelta = 5, sponsorDelta = 1500, trigger = "race_finished_clean"},
  ["minor_crash"] = {id = "minor_crash", trustDelta = -6, sponsorDelta = -1000, trigger = "damage_minor"},
  ["major_crash"] = {id = "major_crash", trustDelta = -30, sponsorDelta = -15000, trigger = "damage_major"},
  ["demotion"] = {id = "demotion", trustDelta = 0, sponsorDelta = 0, trigger = "trust_below_tier_minimum"},
}
local order = {"f4", "f3", "f2", "f1"}
local savePath = 'settings/roadToF1Career.json'
local state = {tier='f4', trust=60, funds=20000, points=0, races=0}
local function clamp(x, lo, hi) return math.max(lo, math.min(hi, x)) end
local function tierIndex(id)
  for i, value in ipairs(order) do if value == id then return i end end
  return 1
end
local function persist()
  if type(jsonWriteFile) ~= 'function' then
    log('W', 'roadToF1', 'jsonWriteFile unavailable: progress not saved')
    return false
  end
  return pcall(jsonWriteFile, savePath, state, true)
end
local function restore()
  if type(jsonReadFile) ~= 'function' then return end
  local ok, saved = pcall(jsonReadFile, savePath)
  if ok and type(saved) == 'table' and tiers[saved.tier] then
    state.tier = saved.tier
    state.trust = clamp(tonumber(saved.trust) or 60, 0, 100)
    state.funds = math.max(0, tonumber(saved.funds) or 20000)
    state.points = math.max(0, tonumber(saved.points) or 0)
    state.races = math.max(0, tonumber(saved.races) or 0)
  end
end
local function announce(msg)
  log('I', 'roadToF1', msg)
  if type(guihooks) == 'table' and type(guihooks.trigger) == 'function' then
    guihooks.trigger('toastrMsg', {type='info', title='Road to F1', msg=msg})
  end
end
function M.getStatus()
  return {tier=state.tier, trust=state.trust, funds=state.funds, points=state.points, races=state.races}
end
function M.showStatus()
  announce(string.format('%s | Trust %d | Funds %d | Points %d | Races %d', state.tier:upper(), state.trust, state.funds, state.points, state.races))
end
-- Prototype 0.2: manually reported incidents; NOT automatic damage detection.
local incidents = {
  ["gravel_excursion"] = {baseRepairCost=0, atFaultTrustPenalty=0},
  ["wing_scrape"] = {baseRepairCost=500, atFaultTrustPenalty=0},
  ["front_wing_bent"] = {baseRepairCost=1500, atFaultTrustPenalty=1},
  ["front_wing_broken"] = {baseRepairCost=6000, atFaultTrustPenalty=3},
  ["puncture"] = {baseRepairCost=2000, atFaultTrustPenalty=1},
  ["suspension_failure"] = {baseRepairCost=25000, atFaultTrustPenalty=10},
  ["heavy_impact"] = {baseRepairCost=80000, atFaultTrustPenalty=20},
  ["write_off"] = {baseRepairCost=150000, atFaultTrustPenalty=30},
 }
-- Incidents charge once per call. Use only at the end of a test incident.
-- Responsibility: 'at_fault', 'racing_incident', 'other_driver', 'mechanical'.
function M.recordTestIncident(incidentId, responsibility)
  local incident = incidents[incidentId]
  if not incident then return false, 'unknown incident' end
  if responsibility ~= 'at_fault' and responsibility ~= 'racing_incident' and responsibility ~= 'other_driver' and responsibility ~= 'mechanical' then
    return false, 'invalid responsibility'
  end
  local repair = math.floor(incident.baseRepairCost * tiers[state.tier].baseRepairMultiplier + 0.5)
  local penalty = responsibility == 'at_fault' and incident.atFaultTrustPenalty or
                  (responsibility == 'racing_incident' and math.floor(incident.atFaultTrustPenalty * 0.25 + 0.5) or 0)
  state.funds = math.max(0, state.funds - repair)
  state.trust = clamp(state.trust - penalty, 0, 100)
  local index = tierIndex(state.tier)
  if state.trust < tiers[state.tier].minimumTrust and index > 1 then
    state.tier = order[index-1]
    state.points = 0
    announce('Seat lost: demoted to ' .. state.tier:upper())
  end
  persist()
  announce(string.format('%s | Repair %d | Trust -%d | %s', incidentId, repair, penalty, responsibility))
  M.showStatus()
  return true
end
-- Manual test entrypoint: not wired to real race or damage events yet.
function M.recordTestEvent(eventId, points)
  local rule = rules[eventId]
  if not rule or eventId == 'demotion' then return false, 'unknown event' end
  state.trust = clamp(state.trust + rule.trustDelta, 0, 100)
  state.funds = math.max(0, state.funds + rule.sponsorDelta)
  state.points = state.points + math.max(0, tonumber(points) or 0)
  state.races = state.races + (eventId == 'clean_finish' and 1 or 0)
  local index = tierIndex(state.tier)
  if state.trust < tiers[state.tier].minimumTrust and index > 1 then
    state.tier = order[index-1]
    state.points = 0
    announce('Seat lost: demoted to ' .. state.tier:upper())
  elseif state.points >= 30 and state.trust >= 75 and index < #order then
    state.tier = order[index+1]
    state.points = 0
    announce('Promoted to ' .. state.tier:upper())
  end
  persist()
  M.showStatus()
  return true
end
local loadBindings
function M.onExtensionLoaded()
  restore()
  loadBindings()
  announce('Career 3.1 loaded (auto damage diagnostic).')
end
function M.onSaveCurrentSaveSlot() persist() end

-- 0.5 diagnostic bridge: only reports damage changes; never bills.
local bridge = {enabled=false, vehicleId=nil, samples=0, last='none', componentDamage={}, epoch=0}
local evaluateMajorCrash443 = function() end
local function playerVehicle()
  local ok, v = pcall(function() return be:getPlayerVehicle(0) end)
  return ok and v or nil
end

-- Prototype 0.6: user-selected installed vehicle bindings. No third-party vehicle assets bundled.
-- Career save is unchanged; bindings are stored separately.
local vehicleBindingsPath = 'settings/roadToF1Vehicles.json'
local vehicleProfiles = {
  f4={mod='Carbonworks F4', setup='F4'},
  f3={mod='Carbonworks F4', setup='GB3'},
  f2={mod='Genesis F2', setup='F2'},
  f1={mod='Genesis F2', setup='F1 career class'}
}
local vehicleBindings = {}
-- Save the selected paint and livery-related part selections as a per-tier snapshot.
-- Captures current BeamNG config; does not claim to automatically reapply it.
local function snapshotAppearance()
  local manager = core_vehicle_partmgmt
  if type(manager) ~= 'table' or type(manager.getConfig) ~= 'function' then
    return nil, 'part management config API unavailable'
  end
  local ok, cfg = pcall(manager.getConfig)
  if not ok or type(cfg) ~= 'table' then return nil, 'vehicle configuration unavailable' end
  local appearance = {captureVersion=3, model=cfg.model}
  -- Carbonworks presets may be separate .pc configurations; Genesis skins may
  -- be chosen via Ctrl+W in a nested part tree. Keep both independently.
  if type(cfg.partConfigFilename) == 'string' then appearance.configFile = cfg.partConfigFilename end
  if type(cfg.paints) == 'table' then appearance.paints = cfg.paints end
  if type(cfg.vars) == 'table' then appearance.vars = cfg.vars end
  if type(cfg.parts) == 'table' then appearance.parts = cfg.parts end
  local selections = {}
  local seen = {}
  local function collect(node, path, depth)
    if type(node) ~= 'table' or seen[node] or depth > 24 then return end
    seen[node] = true
    if type(node.chosenPartName) == 'string' then
      selections[#selections+1] = {slot=tostring(node.id or path), part=node.chosenPartName}
    end
    if type(node.children) == 'table' then
      for key,child in pairs(node.children) do collect(child, path..'/'..tostring(key), depth+1) end
    end
  end
  if type(cfg.partsTree) == 'table' then collect(cfg.partsTree, 'root', 0) end
  appearance.selectedParts = selections
  -- Flatten nested Ctrl+W selections to BeamNG's part-slot map for restoration.
  local partMap = {}
  for _, item in ipairs(selections) do
    if item.slot ~= 'nil' and type(item.part) == 'string' and item.part ~= '' then
      partMap[item.slot] = item.part
    end
  end
  appearance.partMap = partMap
  if not appearance.configFile and not appearance.paints and not appearance.parts and #selections == 0 then
    return nil, 'no configuration information exposed'
  end
  return appearance
end
loadBindings = function()
  if type(jsonReadFile) ~= 'function' then return end
  local ok, data = pcall(jsonReadFile, vehicleBindingsPath)
  if ok and type(data) == 'table' then
    for tier, binding in pairs(data) do
      if vehicleProfiles[tier] and type(binding) == 'table' and
         type(binding.model) == 'string' and #binding.model > 0 and
         type(binding.setup) == 'string' and #binding.setup > 0 then
        vehicleBindings[tier] = {model=binding.model, setup=binding.setup, appearance=type(binding.appearance)=='table' and binding.appearance or nil}
      end
    end
  end
end
local function saveBindings()
  if type(jsonWriteFile) ~= 'function' then return false, 'JSON writer unavailable' end
  local ok, err = pcall(jsonWriteFile, vehicleBindingsPath, vehicleBindings, true)
  return ok, err
end
local function currentModel()
  local v = playerVehicle()
  if not v then return nil, 'no player vehicle' end
  local ok, model = pcall(function() return v:getJBeamFilename() end)
  if not ok or type(model) ~= 'string' or model == '' then
    return nil, 'vehicle model identifier unavailable'
  end
  return model
end
function M.showVehiclePlan()
  for _, tier in ipairs(order) do
    local p, b = vehicleProfiles[tier], vehicleBindings[tier]
    log('I','roadToF1',string.format('%s: %s / %s | bound model %s | bound setup %s',
      tier:upper(),p.mod,p.setup,b and b.model or '(not captured)',b and b.setup or '(not captured)'))
  end
end
-- Select the intended vehicle/setup in BeamNG before calling. Setup is explicitly
-- named by the player because vehicle configuration identifiers vary by mod version.
function M.bindCurrentVehicle(tier, setup)
  if not vehicleProfiles[tier] then return false, 'unknown tier' end
  if type(setup) ~= 'string' or #setup < 1 or #setup > 100 then
    return false, 'supply the setup name visible in vehicle selector'
  end
  local model, err = currentModel()
  if not model then announce('Binding failed: '..err); return false, err end
  local appearance, appearanceError = snapshotAppearance()
  vehicleBindings[tier] = {model=model, setup=setup, appearance=appearance}
  if not appearance then log('W','roadToF1','Appearance not captured: '..tostring(appearanceError)) end
  local saved, saveErr = saveBindings()
  announce(string.format('%s vehicle bound: %s / %s | saved %s',tier:upper(),model,setup,tostring(saved)))
  return saved, saveErr
end
-- Re-capture a changed skin/paint without changing the tier's car binding.
function M.saveCurrentLivery(tier)
  tier = tier or state.tier
  if not vehicleProfiles[tier] then return false, 'unknown tier' end
  local b = vehicleBindings[tier]
  if not b then return false, 'bind the tier vehicle first' end
  local model, err = currentModel()
  if not model then return false, err end
  if model ~= b.model then return false, 'selected vehicle does not match bound model' end
  local appearance, why = snapshotAppearance()
  if not appearance then announce('Livery capture unavailable: '..why); return false, why end
  b.appearance = appearance
  local ok, writeErr = saveBindings()
  announce(string.format('%s livery snapshot saved %s',tier:upper(),tostring(ok)))
  return ok, writeErr
end
function M.showSavedLivery(tier)
  tier = tier or state.tier
  local b = vehicleBindings[tier]
  if not b or not b.appearance then announce('No captured livery for '..tostring(tier)); return false end
  local a = b.appearance
  local slots = {}
  for _,item in ipairs(a.selectedParts or {}) do
    if type(item) == 'table' and type(item.part) == 'string' then slots[#slots+1] = item.part end
  end
  announce(string.format('%s config saved | preset %s | paints %s | selected parts %d', tier:upper(),
    tostring(a.configFile or '(unknown)'), tostring(a.paints and #a.paints or 0), #slots))
  return true
end
-- Prototype 0.9: explicit, guarded restoration to the currently selected car.
-- No spawning or automatic overwrite; use preview before apply.
function M.previewSavedVehicle(tier)
  tier = tier or state.tier
  local b = vehicleBindings[tier]
  if not b or not b.appearance then return false, 'no saved appearance for tier' end
  local a = b.appearance
  local parts = a.partMap or {}
  local count = 0
  for _ in pairs(parts) do count = count + 1 end
  announce(string.format('%s saved model %s | preset %s | parts %d | skin %s',
    tier:upper(), tostring(b.model), tostring(a.configFile), count,
    tostring(parts.paint_design or '(none)')))
  return true
end
function M.restoreSavedVehicle(tier)
  tier = tier or state.tier
  local b = vehicleBindings[tier]
  if not b or not b.appearance then return false, 'no saved appearance for tier' end
  local model, why = currentModel()
  if not model then return false, why end
  if model ~= b.model then return false, 'load the correct vehicle model first' end
  local manager = core_vehicle_partmgmt
  if type(manager) ~= 'table' or type(manager.setConfig) ~= 'function' then
    announce('Restore not supported: part manager setConfig unavailable')
    return false, 'setConfig unavailable'
  end
  local a = b.appearance
  local parts = a.partMap or a.parts
  if type(parts) ~= 'table' or not next(parts) then
    return false, 'saved part selections unavailable; refusing partial restore'
  end
  -- Confirm current config can be read before making any changes.
  local ok, current = pcall(manager.getConfig)
  if not ok or type(current) ~= 'table' or current.model ~= b.model then
    return false, 'current configuration could not be verified'
  end
  local config = {
    model=b.model, parts=parts,
    paints=a.paints or current.paints,
    vars=a.vars or current.vars
  }
  local applied, result = pcall(manager.setConfig, config)
  if not applied or result == false then
    announce('Restore failed: '..tostring(result))
    return false, result
  end
  announce(tier:upper()..' saved parts and paint restore requested; inspect car visually')
  return true
end
-- Prototype 1.0: switch across vehicle models using a saved, complete .pc preset.
-- This intentionally does NOT mutate career funds/trust or overwrite stored bindings.
-- The selected preset is authoritative: Carbonworks F4/GB3 and Genesis liveries
-- have already been captured through BeamNG's vehicle configuration interface.
function M.loadCareerVehicle(tier)
  tier = tier or state.tier
  if not vehicleProfiles[tier] then return false, 'unknown tier' end
  local b = vehicleBindings[tier]
  if not b or type(b.model) ~= 'string' or not b.appearance then
    return false, 'no saved vehicle for tier; bind and save it first'
  end
  local preset = b.appearance.configFile
  if type(preset) ~= 'string' or not preset:match('^vehicles/[%w_%-/]+%.pc$') then
    return false, 'missing or invalid .pc preset; refusing to replace vehicle'
  end
  if type(core_vehicles) ~= 'table' or type(core_vehicles.replaceVehicle) ~= 'function' then
    return false, 'replaceVehicle API unavailable'
  end
  local v = playerVehicle()
  if not v then return false, 'no current player vehicle' end
  -- Damage telemetry will rearm after replacement via onUpdate.
  bridge.enabled = false
  local ok, result = pcall(core_vehicles.replaceVehicle, b.model, {config=preset})
  if not ok or result == false then
    announce('Vehicle switch failed: '..tostring(result))
    return false, tostring(result)
  end
  announce(string.format('%s vehicle switch requested: %s / %s', tier:upper(), b.model, preset))
  return true
end
-- Read-only status for preflight and debugging.
function M.previewCareerSwitch(tier)
  tier = tier or state.tier
  local b = vehicleBindings[tier]
  if not b or not b.appearance then return false, 'no saved binding' end
  announce(string.format('Switch preview %s: model %s | preset %s', tier:upper(), tostring(b.model), tostring(b.appearance.configFile)))
  return true
end

function M.checkCareerVehicle()
  local model, err = currentModel()
  if not model then announce(err); return false, err end
  local b = vehicleBindings[state.tier]
  if not b then announce('No vehicle binding for '..state.tier:upper()); return false, 'unbound' end
  if b.model ~= model then
    announce(string.format('%s expects model %s; driving %s',state.tier:upper(),b.model,model))
    return false, 'wrong model'
  end
  announce(string.format('%s model matches (%s); confirm setup %s in vehicle selector',state.tier:upper(),model,b.setup))
  return true, 'model matches; setup requires visual confirmation'
end

local function startVehicle(v)
  v:queueLuaCommand("extensions.load('roadToF1Damage')")
  v:queueLuaCommand("if extensions.roadToF1Damage then extensions.roadToF1Damage.start() end")
end
function M.receiveDamageDelta(vehicleId, entries)
  if not bridge.enabled then return end
  local v = playerVehicle()
  if not v or v:getId() ~= tonumber(vehicleId) or type(entries) ~= 'table' then return end
  bridge.samples = bridge.samples + 1
  bridge.epoch = (bridge.epoch or 0) + 1
  local out = {}
  for i=1, math.min(#entries, 12) do
    local e = entries[i]
    if type(e) == 'table' and type(e.group) == 'string' and type(e.name) == 'string' then
      out[#out+1] = e.group .. '.' .. e.name .. '=' .. tostring(e.value)
    end
  end
  -- HUD damage observations are diagnostic; never deduct money here.
  bridge.hudDamage = bridge.hudDamage or {}
  for _,e in ipairs(entries) do
    if type(e)=='table' and e.group=='body' and type(e.name)=='string' and type(e.value)=='number' then
      bridge.hudDamage[e.name]=math.max(bridge.hudDamage[e.name] or 0,e.value)
    end
  end
  bridge.componentDamage = bridge.componentDamage or {}
  for _,e in ipairs(entries) do
    if type(e)=='table' and type(e.group)=='string' and type(e.name)=='string' then
      local group=e.group:lower()
      local name=e.name:lower()
      if group=='wheels' or group=='suspension' or name:find('suspension',1,true) or name:find('controlarm',1,true) or name:find('tie_rod',1,true) or name:find('steering',1,true) then
        local key=e.group..'.'..e.name
        local n=(e.value==true and 1) or (type(e.value)=='number' and math.max(0,e.value)) or 0
        bridge.componentDamage[key]=math.max(bridge.componentDamage[key] or 0,n)
      end
    end
  end
  bridge.last = table.concat(out, ', ')
  evaluateMajorCrash443()
  log('I', 'roadToF1', 'Damage delta ' .. bridge.samples .. ': ' .. bridge.last)
end
function M.enableAutoDamage()
  local v = playerVehicle()
  if not v then announce('No player vehicle'); return false end
  bridge.enabled, bridge.vehicleId, bridge.samples, bridge.last = true, v:getId(), 0, 'waiting'
  bridge.hudDamage = {}
  bridge.componentDamage = {}
  startVehicle(v)
  announce('Damage callback bridge ON (diagnostic only, no charges)')
  return true
end
function M.disableAutoDamage() bridge.enabled=false; announce('Damage bridge OFF') end
function M.autoDamageStatus()
  announce(string.format('Bridge %s | vehicle %s | deltas %d | %s', tostring(bridge.enabled), tostring(bridge.vehicleId), bridge.samples, bridge.last))
end
function M.onUpdate()
  if not bridge.enabled then return end
  local v = playerVehicle()
  if v and v:getId() ~= bridge.vehicleId then
    bridge.vehicleId, bridge.samples, bridge.last = v:getId(), 0, 'waiting'
    bridge.hudDamage = {}
    bridge.componentDamage = {}
    startVehicle(v)
  end
end

-- Road to F1 2.0: vehicle switching, persistent weekend simulation and standings.
-- This release does not spawn track AI or infer race finishes from driving.
local weekendPath = 'settings/roadToF1Weekend.json'
local championship = {season=1, round=1, phase='idle', tier='f4', team='Independent', results={}, standings={}, sponsor=0}
local raceTeams = {'Apex', 'Velocity', 'Meridian', 'Northstar', 'Orion', 'Summit', 'Falcon', 'Vector', 'Titan', 'Aurora'}
local raceNames = {'Hirochi Raceway', 'West Coast', 'Automation Test Track', 'Italy', 'East Coast', 'Utah'}
local function copyData(t)
  if type(t) ~= 'table' then return nil end
  local o={}
  for k,v in pairs(t) do if type(v) == 'table' then o[k]=copyData(v) else o[k]=v end end
  return o
end
local function loadWeekend()
  if type(jsonReadFile) ~= 'function' then return end
  local ok, data=pcall(jsonReadFile, weekendPath)
  if ok and type(data)=='table' and type(data.results)=='table' and type(data.standings)=='table' then
    championship=data
    championship.phase=championship.phase or 'idle'
    championship.round=tonumber(championship.round) or 1
    championship.season=tonumber(championship.season) or 1
    championship.team=championship.team or 'Independent'
  end
end
local function saveWeekend()
  if type(jsonWriteFile) ~= 'function' then return false end
  local ok, result=pcall(jsonWriteFile,weekendPath,championship,true)
  return ok and result ~= false
end
local oldLoaded=M.onExtensionLoaded
function M.onExtensionLoaded()
  oldLoaded()
  loadWeekend()
  announce('2.0 systems ready: showWeekend(), chooseTeam(), startWeekend()')
end
local oldSave=M.onSaveCurrentSaveSlot
function M.onSaveCurrentSaveSlot(...)
  if oldSave then oldSave(...) end
  saveWeekend()
end
local function partSelections(tree, map, seen)
  if type(tree)~='table' or seen[tree] then return end
  seen[tree]=true
  local slot=tostring(tree.id or '')
  if map[slot] and type(tree.chosenPartName)=='string' then tree.chosenPartName=map[slot] end
  if type(tree.children)=='table' then
    for _,child in pairs(tree.children) do partSelections(child,map,seen) end
  end
end
local pendingSwitch=nil
local function activeConfig()
  local ok,c=pcall(core_vehicle_partmgmt.getConfig)
  return ok and type(c)=='table' and c or nil
end
local function verifySkin(tier)
  local b=vehicleBindings[tier]
  local c=activeConfig()
  if not c or not b or not b.appearance then return false,'configuration unavailable' end
  local expected=(b.appearance.partMap or {}).paint_design
  if not expected then return true,'no separate skin slot saved' end
  local got=nil
  local function walk(n,seen)
    if type(n)~='table' or seen[n] then return end
    seen[n]=true
    if n.id=='paint_design' then got=n.chosenPartName end
    for _,v in pairs(n.children or {}) do walk(v,seen) end
  end
  walk(c.partsTree,{})
  return expected==got, 'expected '..tostring(expected)..', actual '..tostring(got)
end
function M.verifyCareerLivery(tier)
  tier=tier or state.tier
  local ok,msg=verifySkin(tier)
  announce(tier:upper()..' livery '..(ok and 'OK: ' or 'MISMATCH: ')..msg)
  return ok,msg
end
local function applySavedAppearance(tier)
  local b=vehicleBindings[tier]
  local c=activeConfig()
  if not b or not b.appearance or not c or c.model~=b.model then return false,'model/config mismatch' end
  local a=b.appearance
  local tree=copyData(c.partsTree)
  if type(tree)=='table' then partSelections(tree,a.partMap or {},{}) end
  local patch={}
  if tree then patch.partsTree=tree end
  if type(a.paints)=='table' then patch.paints=copyData(a.paints) end
  if type(a.vars)=='table' then patch.vars=copyData(a.vars) end
  if not next(patch) then return false,'no saved appearance data' end
  local ok,err=pcall(core_vehicle_partmgmt.setConfig,patch,true)
  if not ok or err==false then return false,tostring(err) end
  return true
end
-- Cross-model replace first; apply nested paint_design and tuning only after the model loads.
function M.loadCareerVehicle(tier)
  tier=tier or state.tier
  local b=vehicleBindings[tier]
  if not b or not b.appearance then return false,'no saved vehicle' end
  local a=b.appearance
  local preset=a.configFile
  if type(preset)~='string' or not preset:match('^vehicles/[%w_%-/]+%.pc$') then return false,'invalid saved preset' end
  if not playerVehicle() then return false,'no player vehicle' end
  if type(core_vehicles.replaceVehicle)~='function' then return false,'replaceVehicle unavailable' end
  if pendingSwitch then return false,'vehicle switch already in progress' end
  bridge.enabled=false
  pendingSwitch={tier=tier, model=b.model, elapsed=0, stable=0, applied=false}
  local ok,ret=pcall(core_vehicles.replaceVehicle,b.model,{config=preset})
  if not ok or ret==false then pendingSwitch=nil; return false,tostring(ret) end
  announce('Loading '..tier:upper()..' model and preset; saved skin will follow')
  return true
end
local previousUpdate=M.onUpdate
function M.onUpdate(dtReal,dtSim,dtRaw)
  if previousUpdate then previousUpdate(dtReal,dtSim,dtRaw) end
  if not pendingSwitch then return end
  local p=pendingSwitch
  p.elapsed=p.elapsed+math.max(0,tonumber(dtReal) or 0.016)
  if p.elapsed>20 then announce('Vehicle restore timed out; no career data changed'); pendingSwitch=nil; return end
  local c=activeConfig()
  if not c or c.model~=p.model then p.stable=0; return end
  p.stable=p.stable+math.max(0,tonumber(dtReal) or 0.016)
  if p.stable<1.5 then return end
  if not p.applied then
    p.applied=true
    local ok,msg=applySavedAppearance(p.tier)
    if not ok then announce('Appearance restore failed: '..tostring(msg)) end
    p.stable=0
    return
  end
  if p.stable<1.5 then return end
  local ok,msg=verifySkin(p.tier)
  announce(p.tier:upper()..' restore '..(ok and 'verified' or 'needs checking')..': '..msg)
  pendingSwitch=nil
end
function M.showWeekend()
  announce(string.format('Season %d | Round %d/%d | %s | %s | Team %s | %s',championship.season,championship.round,#raceNames,
    state.tier:upper(),tostring(championship.phase),championship.team,raceNames[((championship.round-1)%#raceNames)+1]))
end
function M.chooseTeam(name)
  if championship.phase~='idle' then return false,'finish current weekend first' end
  if type(name)~='string' or #name<2 or #name>48 or not name:match('^[%w %-%_]+$') then return false,'invalid team name' end
  championship.team=name
  saveWeekend()
  announce('Team contract selected: '..name)
  return true
end
function M.startWeekend()
  if championship.phase~='idle' then return false,'weekend already active' end
  if not vehicleBindings[state.tier] then return false,'bind current tier vehicle first' end
  championship.tier=state.tier
  championship.phase='practice'
  championship.practice=nil; championship.qualifying=nil
  saveWeekend(); M.showWeekend()
  return true
end
function M.completePractice(lapSeconds)
  if championship.phase~='practice' then return false,'practice not active' end
  local lap=tonumber(lapSeconds)
  if not lap or lap<30 or lap>600 then return false,'lapSeconds must be 30..600' end
  championship.practice=lap
  championship.phase='qualifying'
  saveWeekend(); announce(string.format('Practice logged %.3fs; qualifying unlocked',lap))
  return true
end
function M.completeQualifying(lapSeconds)
  if championship.phase~='qualifying' then return false,'qualifying not active' end
  local lap=tonumber(lapSeconds)
  if not lap or lap<30 or lap>600 then return false,'lapSeconds must be 30..600' end
  championship.qualifying=lap
  -- Deterministic synthetic field for testing, NOT live AI cars.
  local seed=championship.season*211+championship.round*37+tierIndex(state.tier)*17
  local grid=1
  for i=1,19 do
    local aiLap=math.max(30, (championship.practice or lap)* (0.968 + ((seed+i*13)%55)/1000))
    if aiLap<lap then grid=grid+1 end
  end
  championship.grid=grid
  championship.phase='race'
  saveWeekend(); announce('Qualifying P'..grid..'/20; race session ready (simulated grid)')
  return true
end
local pointsTable={25,18,15,12,10,8,6,4,2,1}
function M.completeRace(position, responsibility)
  if championship.phase~='race' then return false,'race session not ready' end
  local pos=tonumber(position)
  if not pos or pos~=math.floor(pos) or pos<1 or pos>21 then return false,'position 1..20, 21 = DNF' end
  if responsibility~=nil and responsibility~='clean' and responsibility~='incident' then return false,'use clean or incident' end
  local pts=pointsTable[pos] or 0
  local pay=pos==21 and 0 or math.floor(400+pts*65)
  local trustChange=pos==21 and -2 or (pos<=5 and 3 or 1)
  if responsibility=='incident' then trustChange=trustChange-2 end
  state.races=state.races+1
  state.points=state.points+pts
  state.funds=math.max(0,state.funds+pay)
  state.trust=clamp(state.trust+trustChange,0,100)
  local key=state.tier..':'..championship.season
  local board=championship.standings[key] or {player=0, rivals={}}
  board.player=board.player+pts
  for i=1,19 do
    local rival='AI '..i
    local rp=((i*7+championship.round*3+championship.season)%20)+1
    board.rivals[rival]=(board.rivals[rival] or 0)+(pointsTable[rp] or 0)
  end
  championship.standings[key]=board
  championship.results[#championship.results+1]={season=championship.season,round=championship.round,tier=state.tier,grid=championship.grid,finish=pos,points=pts,pay=pay}
  championship.phase='idle'; championship.round=championship.round+1
  if championship.round>#raceNames then
    championship.round=1; championship.season=championship.season+1
    local idx=tierIndex(state.tier)
    if state.trust<tiers[state.tier].minimumTrust and idx>1 then
      state.tier=order[idx-1]; state.points=0; announce('Contract lost: demoted to '..state.tier:upper())
    elseif state.points>=60 and state.trust>=75 and idx<#order then
      state.tier=order[idx+1]; state.points=0; announce('Promoted to '..state.tier:upper())
    end
  end
  persist(); saveWeekend()
  announce(string.format('Race P%d | +%d points | +%d funds | trust %+d',pos,pts,pay,trustChange))
  return true
end
function M.showStandings()
  local key=state.tier..':'..championship.season
  local board=championship.standings[key] or {player=0,rivals={}}
  local entries={{name='YOU',points=board.player}}
  for name,pts in pairs(board.rivals or {}) do entries[#entries+1]={name=name,points=pts} end
  table.sort(entries,function(a,b) if a.points==b.points then return a.name<b.name end return a.points>b.points end)
  for i=1,math.min(#entries,10) do log('I','roadToF1',string.format('P%d %s: %d',i,entries[i].name,entries[i].points)) end
end
function M.cancelWeekend()
  if championship.phase=='idle' then return false,'no weekend active' end
  championship.phase='idle'; championship.practice=nil; championship.qualifying=nil
  saveWeekend(); announce('Weekend cancelled; no points or payouts awarded')
  return true
end
function M.getWeekendState() return copyData(championship) end

-- Road to F1 3.0: live, player-driven timing. Manual start/finish gate calibration.
-- This does NOT pretend to have physical AI or automatic finishing position detection.
local live={active=false,armed=false,inside=false,laps=0,elapsed=0,last=0,best=nil,session=nil,gate=nil,vehicleId=nil,lapDamageEpoch=0,lapCleanEligible=false,initialInside=false,cleanStreak=0,lapEarnings=0,lastLapReward=nil,lastLapTime=nil}
local function currentPosition()
  local v=playerVehicle()
  if not v or type(v.getPosition)~='function' then return nil,nil end
  local ok,p=pcall(v.getPosition,v)
  if not ok or not p then return nil,nil end
  local x,y,z=tonumber(p.x),tonumber(p.y),tonumber(p.z)
  if not x or not y or not z then return nil,nil end
  return {x=x,y=y,z=z},v:getId()
end
local function distanceSquared(a,b)
  local dx,dy,dz=a.x-b.x,a.y-b.y,a.z-b.z
  return dx*dx+dy*dy+dz*dz
end
function M.setTimingGate(radius)
  if live.active then return false,'stop timing before recalibrating' end
  local p=currentPosition()
  if not p then return false,'no valid player vehicle position' end
  radius=tonumber(radius) or 8
  if radius<4 or radius>25 then return false,'radius must be 4..25 metres' end
  live.gate={position=p,radius=radius}
  announce(string.format('Timing gate saved at current position (radius %.1fm)',radius))
  -- Setting the gate at the start line also arms practice/qualifying.
  if championship.phase=='practice' or championship.phase=='qualifying' then
    local ok,msg=M.startLiveSession()
    if not ok then announce('Gate saved; timing not armed: '..tostring(msg)) end
  end
  return true
end
function M.startLiveSession()
  if live.active then return false,'timing already running' end
  if championship.phase~='practice' and championship.phase~='qualifying' and championship.phase~='race' then return false,'startWeekend first' end
  if not live.gate then return false,'setTimingGate at the start/finish line first' end
  local cfg=activeConfig()
  local expected=vehicleBindings[state.tier]
  if not expected or not cfg or cfg.model~=expected.model then return false,'wrong car for current career tier' end
  local p,id=currentPosition()
  if not p then return false,'vehicle position unavailable' end
  live.active=true; live.armed=false; live.inside=false; live.laps=0; live.elapsed=0; live.last=0
  live.best=nil; live.session=championship.phase; live.vehicleId=id
  live.inside=distanceSquared(p,live.gate.position)<=live.gate.radius*live.gate.radius
  live.initialInside=live.inside
  live.lapDamageEpoch=bridge.epoch or 0; live.lapCleanEligible=false; live.cleanStreak=0; live.lapEarnings=0; live.lastLapReward=nil; live.lastLapTime=nil
  announce('LIVE '..live.session..' timing armed. Drive outside gate then cross start/finish. No simulated lap times.')
  return true
end
function M.liveTimingStatus()
  announce(string.format('Live %s | session %s | laps %d | elapsed %.1fs | best %s | armed %s',tostring(live.active),tostring(live.session),live.laps,live.elapsed,live.best and string.format('%.3fs',live.best) or 'none',tostring(live.armed)))
end
function M.stopLiveSession()
  if not live.active then return false,'no live session active' end
  live.active=false
  announce('Live timing stopped; no result or payout automatically recorded')
  return true
end
function M.submitLiveSession()
  if live.active then return false,'stopLiveSession first' end
  if not live.best or live.session~=championship.phase then return false,'no completed timed lap for current phase' end
  if live.session=='practice' then return M.completePractice(live.best) end
  if live.session=='qualifying' then return M.completeQualifying(live.best) end
  return false,'race finish position needs validated race control; no automatic points awarded'
end
-- Auto-arm diagnostic monitoring, including after vehicle replacement.
-- No automatic repair charges or trust penalties are applied.
local autoDamageWanted=true
local autoDamageCooldown=0
function M.setAutoDamageStartup(enabled)
  autoDamageWanted=(enabled~=false)
  if not autoDamageWanted then M.disableAutoDamage() end
  announce('Auto damage startup '..tostring(autoDamageWanted))
  return true
end
local updateBeforeLive=M.onUpdate
function M.onUpdate(dtReal,dtSim,dtRaw)
  if updateBeforeLive then updateBeforeLive(dtReal,dtSim,dtRaw) end
  autoDamageCooldown=autoDamageCooldown+math.max(0,tonumber(dtReal) or 0)
  if autoDamageWanted and not bridge.repairPending and not pendingSwitch and autoDamageCooldown>=1 and (not bridge.enabled or (playerVehicle() and bridge.vehicleId~=playerVehicle():getId())) then
    autoDamageCooldown=0
    if playerVehicle() then M.enableAutoDamage() end
  end
  if not live.active then return end
  if championship.phase~=live.session then live.active=false; return end
  local p,id=currentPosition()
  if not p or id~=live.vehicleId then
    live.active=false; announce('Live timing cancelled: vehicle changed'); return
  end
  local dt=math.max(0,math.min(0.25,tonumber(dtSim) or 0))
  live.elapsed=live.elapsed+dt
  local inside=distanceSquared(p,live.gate.position)<=live.gate.radius*live.gate.radius
  -- The driver must leave the gate before triggering it; gate radius must not be too large.
  if not inside then
    if live.initialInside and live.last==0 then
      live.last=live.elapsed
      live.initialInside=false
      live.lapDamageEpoch=bridge.epoch or 0
      announce('Timing started leaving start/finish; next crossing completes lap 1')
    end
    live.armed=true
  end
  if inside and not live.inside and live.armed then
    live.armed=false
    if live.last>0 then
      local lap=live.elapsed-live.last
      if lap>=30 and lap<=600 then
        live.laps=live.laps+1
        if not live.best or lap<live.best then live.best=lap end
        -- Rewards depend on lap time, not whether damage occurred.
        -- The timing system rejects laps shorter than 30 seconds as invalid.
        -- Under 60 seconds: 200; 60 through 120 seconds: 100; over 120: 0.
        local reward=(lap<60 and 200) or (lap<=120 and 100) or 0
        state.funds=state.funds+reward
        live.lapEarnings=(live.lapEarnings or 0)+reward
        live.lastLapReward=reward
        live.lastLapTime=lap
        local clean=(bridge.epoch or 0)==(live.lapDamageEpoch or 0)
        live.cleanStreak=clean and ((live.cleanStreak or 0)+1) or 0
        if live.cleanStreak>=5 then
          state.trust=clamp(state.trust+2,0,100)
          live.cleanStreak=0
          announce('FIVE CLEAN LAPS: +2 TEAM TRUST | Trust '..state.trust..'/100')
        end
        persist()
        announce(string.format('LAP %d COMPLETE: +£%d | Funds £%d | %.3fs%s',live.laps,reward,state.funds,lap,clean and ' | CLEAN' or ' | DAMAGE RECORDED'))
        announce(string.format('LIVE %s lap %d: %.3fs | best %.3fs',live.session,live.laps,lap,live.best))
      else
        announce(string.format('Lap %.2fs rejected (valid range 30..600s)',lap))
      end
    else
      announce('Timing line crossed: lap clock started')
    end
    live.last=live.elapsed
    live.lapDamageEpoch=bridge.epoch or 0
    live.lapCleanEligible=true
  end
  live.inside=inside
end


-- Road to F1 4.0: measured player race laps against a persistent simulated field.
-- No physical AI vehicles; no automatic damage fees or unsupported component inference.
local race40 = {active=false, target=5, completed=false, startElapsed=nil, field=nil, result=nil}
local function aiSeed40(i)
  return championship.season*97 + championship.round*53 + tierIndex(state.tier)*31 + i*17
end
local function aiLap40(i, reference)
  local seed=aiSeed40(i)
  local skill=((seed*37)%101)/100
  local variation=((seed*19)%17-8)/1000
  return math.max(30,reference*(0.965+0.065*skill+variation))
end
local function field40(reference)
  local t={}
  for i=1,19 do
    local lap=aiLap40(i,reference)
    t[#t+1]={name='AI '..i, lap=lap, time=lap*race40.target*(1+((aiSeed40(i)%13)-6)/1000)}
  end
  return t
end
local function finishRace40(dnf)
  if race40.completed or championship.phase~='race' then return false,'race not active' end
  race40.completed=true
  race40.active=false
  live.active=false
  local elapsed=live.elapsed-(race40.startElapsed or 0)
  local position=21
  if not dnf then
    position=1
    for _,r in ipairs(race40.field or {}) do if r.time<elapsed then position=position+1 end end
  end
  race40.result={dnf=dnf and true or false, position=position, elapsed=elapsed, laps=live.laps}
  local ok,msg=M.completeRace(position,dnf and 'incident' or 'clean')
  if not ok then return false,msg end
  announce(string.format('4.0 RACE %s | %d/%d laps | %.3fs | simulated rivals',dnf and 'DNF' or ('P'..position),live.laps,race40.target,elapsed))
  return true
end
function M.setRaceDistance(laps)
  if championship.phase=='race' and race40.active then return false,'race in progress' end
  laps=tonumber(laps)
  if not laps or laps~=math.floor(laps) or laps<2 or laps>50 then return false,'laps must be 2..50' end
  race40.target=laps
  announce('Race distance set to '..laps..' laps')
  return true
end
function M.startMeasuredRace()
  if championship.phase~='race' then return false,'complete qualifying first' end
  if race40.active then return false,'race already active' end
  local ref=tonumber(championship.qualifying or championship.practice)
  if not ref then return false,'qualifying time required' end
  local ok,msg=M.startLiveSession()
  if not ok then return false,msg end
  race40.field=field40(ref)
  race40.completed=false
  race40.active=true
  race40.result=nil
  race40.startElapsed=nil
  announce(string.format('Measured race armed: %d laps, 19 simulated opponents; first crossing starts clock',race40.target))
  return true
end
function M.race40Status()
  if not race40.active then
    announce('Measured race inactive | last '..(race40.result and (race40.result.dnf and 'DNF' or 'P'..race40.result.position) or 'none'))
    return
  end
  local completed=math.max(0,live.laps)
  local time=math.max(0,live.elapsed-(race40.startElapsed or live.elapsed))
  local ahead=0
  for _,r in ipairs(race40.field or {}) do if r.time<time then ahead=ahead+1 end end
  announce(string.format('Measured race | %d/%d laps | %.1fs | %d simulated rivals projected ahead at finish',completed,race40.target,time,ahead))
end
function M.retireMeasuredRace(reason)
  if not race40.active then return false,'no measured race active' end
  if reason~='crash' and reason~='mechanical' then return false,'reason must be crash or mechanical' end
  announce('Retirement confirmed: '..reason..' (no automatic repair fee)')
  return finishRace40(true)
end
local oldUpdate40=M.onUpdate
function M.onUpdate(dtReal,dtSim,dtRaw)
  if oldUpdate40 then oldUpdate40(dtReal,dtSim,dtRaw) end
  if not race40.active then return end
  if not live.active or championship.phase~='race' then
    race40.active=false
    announce('Measured race stopped without classification')
    return
  end
  if not race40.startElapsed and live.last>0 then race40.startElapsed=live.last end
  if race40.startElapsed and live.laps>=race40.target then finishRace40(false) end
end
local oldStop40=M.stopLiveSession
function M.stopLiveSession()
  if race40.active then
    race40.active=false
    announce('Measured race aborted; no result recorded')
  end
  return oldStop40()
end
local oldCancel40=M.cancelWeekend
function M.cancelWeekend()
  race40.active=false
  live.active=false
  return oldCancel40()
end
local oldLoad40=M.onExtensionLoaded
function M.onExtensionLoaded()
  if oldLoad40 then oldLoad40() end
  announce('Road to F1 4.0 measured-race module ready (simulated AI, no physical cars)')
end


-- 4.4: provisional component-aware repairs and sponsor contracts.
-- Wing detachment requires manual confirmation; body damage alone is insufficient.
local wing44={confirmed=false, vehicleId=nil}
local major443={charged=false,vehicleId=nil, lastMessage='No major crash recorded'}
local sponsor44Path='settings/roadToF1Sponsors.json'
local sponsor44={active='none', paidRaces=0, lastBonus=0}
local sponsorOffers44={
  none={name='No sponsor',base=0,topTen=0,podium=0},
  localgarage={name='Local Garage',base=250,topTen=100,podium=150},
  tracktech={name='TrackTech',base=450,topTen=250,podium=350},
  velocity={name='Velocity Racing',base=600,topTen=350,podium=650}
}
local function sponsorLoad44()
  if type(jsonReadFile)~='function' then return end
  local ok,data=pcall(jsonReadFile,sponsor44Path)
  if ok and type(data)=='table' and sponsorOffers44[data.active] then
    sponsor44.active=data.active
    sponsor44.paidRaces=tonumber(data.paidRaces) or 0
    sponsor44.lastBonus=tonumber(data.lastBonus) or 0
  end
end
local function sponsorSave44()
  if type(jsonWriteFile)=='function' then pcall(jsonWriteFile,sponsor44Path,sponsor44,true) end
end
function M.chooseSponsor(id)
  if not sponsorOffers44[id] then return false,'unknown sponsor' end
  if championship.phase~='idle' then return false,'change sponsors between weekends' end
  sponsor44.active=id
  sponsorSave44()
  announce('Sponsor selected: '..sponsorOffers44[id].name)
  return true,sponsorOffers44[id].name
end
function M.confirmWingDetached()
  local v=playerVehicle()
  if not v or not bridge.enabled or bridge.vehicleId~=v:getId() then return false,'damage monitoring not ready' end
  if wing44.vehicleId==v:getId() and wing44.confirmed then return false,'wing already marked detached' end
  wing44.vehicleId=v:getId()
  wing44.confirmed=true
  evaluateMajorCrash443()
  announce('Front wing marked detached; fixed replacement estimate applied (no automatic charge)')
  return true,'front wing detached confirmed'
end
local function wingPrice44()
  return ({f4=1000,f3=1000,f2=10000,f1=20000})[state.tier] or 1000
end
local function componentEstimate44()
  local count,severity=0,0
  for _,v in pairs(bridge.componentDamage or {}) do
    if type(v)=='number' and v>0 then count=count+1;severity=math.max(severity,v) end
  end
  local multiplier=tiers[state.tier].baseRepairMultiplier
  local low= count>0 and math.floor((300+1200*math.min(severity,1))*multiplier+0.5) or 0
  local high=count>0 and math.floor((1500+6000*math.min(severity,1))*multiplier+0.5) or 0
  return low,high,count
end
-- Wrap race completion: one sponsor payment per successful race completion.
local originalCompleteRace44=M.completeRace
function M.completeRace(position,responsibility)
  local ok,msg=originalCompleteRace44(position,responsibility)
  if not ok then return ok,msg end
  local offer=sponsorOffers44[sponsor44.active] or sponsorOffers44.none
  local pos=tonumber(position) or 21
  local bonus=offer.base+(pos<=10 and offer.topTen or 0)+(pos<=3 and offer.podium or 0)
  if pos==21 then bonus=0 end
  sponsor44.lastBonus=bonus
  sponsor44.paidRaces=sponsor44.paidRaces+1
  if bonus>0 then state.funds=state.funds+bonus;persist();announce('Sponsor '..offer.name..': +£'..bonus) end
  sponsorSave44()
  return ok,msg
end
local previousLoaded44=M.onExtensionLoaded
function M.onExtensionLoaded(...)
  if previousLoaded44 then previousLoaded44(...) end
  sponsorLoad44()
end

-- 4.3.2: voluntary pit repair. One bill per newly observed damage episode.
-- This is a user-confirmed pit action, not GPS-based pit detection.
local pitRepair432={busy=false, rearmPending=false, rearmElapsed=0, rearmAttempts=0,
  lastCost=0, lastMessage='No repairs yet', lastRepairedEpoch=-1, repairedVehicle=nil}
local function pitRange432()
  local d=bridge.hudDamage or {}
  local severity=0
  for _,key in ipairs({'FL','FR','ML','MR','RL','RR'}) do
    severity=math.max(severity,tonumber(d[key]) or 0)
  end
  local multiplier=tiers[state.tier].baseRepairMultiplier
  local low=math.floor(severity*10000*multiplier+0.5)
  local high=math.floor(severity*40000*multiplier+0.5)
  return low,math.max(low,math.floor(low+(high-low)*0.375+0.5)),high
end
-- First available home spawn captured at map start, before driving. This is a
-- conservative fallback; not an authoritative named pit-lane spawn point.
local homeSpawn45=nil
local homeSpawnCapture45=0
local function captureHomeSpawn45(dt)
  if homeSpawn45 then return end
  homeSpawnCapture45=homeSpawnCapture45+math.max(0,tonumber(dt) or 0)
  if homeSpawnCapture45<1.5 then return end
  local v=playerVehicle()
  if not v then return end
  local ok,p=pcall(v.getPosition,v)
  local okr,r=pcall(v.getRotation,v)
  if ok and p and okr and r then
    homeSpawn45={pos=vec3(p.x,p.y,p.z),rot=r}
    announce('Home return location captured at initial vehicle spawn')
  end
end
local oldMission45=M.onClientStartMission
function M.onClientStartMission(...)
  homeSpawn45=nil; homeSpawnCapture45=0
  if oldMission45 then oldMission45(...) end
end
local oldHomeUpdate45=M.onUpdate
function M.onUpdate(dtReal,dtSim,dtRaw)
  if oldHomeUpdate45 then oldHomeUpdate45(dtReal,dtSim,dtRaw) end
  captureHomeSpawn45(dtReal)
end
local function repairVehicle45(tow)
  if pitRepair432.busy or pitRepair432.rearmPending or pendingSwitch then
    return false,'vehicle operation in progress'
  end
  local veh=playerVehicle()
  if not veh then return false,'no player vehicle' end
  local vid=veh:getId()
  if not bridge.enabled or bridge.vehicleId~=vid then
    return false,'damage monitor not ready for current vehicle'
  end
  local low,discountHigh,originalHigh=pitRange432()
  local sl,sh=componentEstimate44()
  local wingCost=(wing44.confirmed and wing44.vehicleId==vid) and wingPrice44() or 0
  low=low+sl+wingCost
  discountHigh=discountHigh+math.floor(sl+(sh-sl)*0.375+0.5)+wingCost
  originalHigh=originalHigh+sh+wingCost
  if low<=0 then return false,'no detected damage to repair' end
  if tow and not homeSpawn45 then return false,'home spawn not captured; return unavailable' end
  if tow and (not spawn or type(spawn.safeTeleport)~='function') then return false,'safeTeleport unavailable; tow cancelled without charge' end
  if pitRepair432.repairedVehicle==vid and pitRepair432.lastRepairedEpoch==(bridge.epoch or 0) then
    return false,'this damage has already been repaired'
  end
  local config=activeConfig()
  if type(config)~='table' or type(serialize)~='function' or type(veh.respawn)~='function' then
    return false,'safe vehicle respawn unavailable'
  end
  pitRepair432.busy=true
  local ok,err=pcall(function()
    if tow then
      local moved=spawn.safeTeleport(veh,homeSpawn45.pos,homeSpawn45.rot)
      if moved==false then error("safeTeleport refused tow") end
    end
    veh:respawn(serialize(config))
  end)
  pitRepair432.busy=false
  if not ok then return false,'repair respawn failed: '..tostring(err) end
  -- Tow pays the upper half of the full estimate; driving to pits gets the discount.
  local lowerBound=tow and math.floor((low+originalHigh)/2+0.5) or low
  local upperBound=tow and originalHigh or discountHigh
  local cost=math.random(lowerBound,math.max(lowerBound,upperBound))
  state.funds=math.max(0,state.funds-cost)
  persist()
  pitRepair432.lastCost=cost
  pitRepair432.lastMessage=string.format('%s: £%d (full estimate £%d–£%d)',tow and 'Tow + repair' or 'Pit repair',cost,low,originalHigh)
  -- A reset may reuse the vehicle ID. Disable the old GE bridge and re-register
  -- the Vehicle Lua callback after the new vehicle finishes initialization.
  pitRepair432.repairedVehicle=vid
  pitRepair432.lastRepairedEpoch=bridge.epoch or 0
  bridge.enabled=false
  bridge.repairPending=true
  bridge.vehicleId=nil
  bridge.hudDamage={}
  bridge.componentDamage={}
  bridge.samples=0
  bridge.last='repairing'
  wing44.confirmed=false
  wing44.vehicleId=nil
  major443.charged=false
  major443.vehicleId=nil
  major443.lastMessage='No major crash recorded'
  live.cleanStreak=0
  pitRepair432.rearmPending=true
  pitRepair432.rearmElapsed=0
  pitRepair432.rearmAttempts=0
  -- A pit repair invalidates the current lap; do not pay for a reset-assisted lap.
  live.lapCleanEligible=false
  if live.active then
    live.active=false
    announce('Timing stopped for pit repair; restart the session to record valid laps')
  end
  announce(pitRepair432.lastMessage)
  return true,pitRepair432.lastMessage
end
function M.pitRepair() return repairVehicle45(false) end
function M.towToPits() return repairVehicle45(true) end
-- Re-arm after respawn, even when BeamNG retains the same vehicle ID.
-- A bounded retry protects against the vehicle not yet being available.
local previousPitUpdate451=M.onUpdate
function M.onUpdate(dtReal,dtSim,dtRaw)
  if previousPitUpdate451 then previousPitUpdate451(dtReal,dtSim,dtRaw) end
  if not pitRepair432.rearmPending then return end
  pitRepair432.rearmElapsed=pitRepair432.rearmElapsed+math.max(0,tonumber(dtReal) or 0)
  if pitRepair432.rearmElapsed<1.5 then return end
  pitRepair432.rearmElapsed=0
  pitRepair432.rearmAttempts=pitRepair432.rearmAttempts+1
  local v=playerVehicle()
  if v then
    local ok, enabled=pcall(function() return M.enableAutoDamage() end)
    if ok and enabled and bridge.enabled and bridge.vehicleId==v:getId() then
      pitRepair432.rearmPending=false
      bridge.repairPending=false
      announce('Damage monitoring re-armed after repair: vehicle '..tostring(v:getId()))
      return
    end
  end
  if pitRepair432.rearmAttempts>=10 then
    pitRepair432.rearmPending=false
    bridge.repairPending=false
    announce('Damage monitor re-arm timed out; use enableAutoDamage() to retry')
  end
end

-- Road to F1 4.1: read-only dashboard data for the BeamNG UI app.
-- Costs are deliberately estimates; no automatic repair charge or DNF is inferred.
local hud41Clock = 0
local function hud41Standings()
  local key=state.tier..':'..championship.season
  local board=championship.standings[key] or {player=0,rivals={}}
  local rows={{name='YOU',points=tonumber(board.player) or 0,player=true}}
  for name,pts in pairs(board.rivals or {}) do
    rows[#rows+1]={name=tostring(name),points=tonumber(pts) or 0,player=false}
  end
  table.sort(rows,function(a,b)
    if a.points==b.points then return a.name<b.name end
    return a.points>b.points
  end)
  for i,r in ipairs(rows) do r.position=i end
  return rows
end
local function hud41Damage()
  local d=bridge.hudDamage or {}
  local front=math.max(tonumber(d.FL) or 0,tonumber(d.FR) or 0)
  local middle=math.max(tonumber(d.ML) or 0,tonumber(d.MR) or 0)
  local rear=math.max(tonumber(d.RL) or 0,tonumber(d.RR) or 0)
  -- Conservative provisional bodywork-only range; not component-level repair accounting.
  local severity=math.max(front,middle,rear)
  local multiplier=tiers[state.tier].baseRepairMultiplier
  local low=math.floor(severity*10000*multiplier+0.5)
  local high=math.floor(severity*40000*multiplier+0.5)
  local suspensionLow,suspensionHigh,suspensionSignals=componentEstimate44()
  local wing=(wing44.confirmed and wing44.vehicleId==bridge.vehicleId) and wingPrice44() or 0
  return {front=front,middle=middle,rear=rear,events=bridge.samples or 0,
    estimateLow=low+suspensionLow+wing,estimateHigh=high+suspensionHigh+wing,
    bodyLow=low,bodyHigh=high,suspensionLow=suspensionLow,suspensionHigh=suspensionHigh,
    suspensionSignals=suspensionSignals,wingCost=wing,wingConfirmed=wing>0,uncertain=true,
    note='Suspension is estimated from available wheel/suspension damage signals; missing signals do not prove it is intact. Wing detachment requires manual confirmation. No automatic charge.'}
end
-- 4.4.3: one trust penalty per damage incident, based on full upper estimate.
-- No automatic money charge; reset only after successful repair/replacement.
evaluateMajorCrash443=function()
  if not bridge.enabled or bridge.repairPending then return end
  local v=playerVehicle()
  if not v or bridge.vehicleId~=v:getId() then return end
  if major443.vehicleId~=v:getId() then major443.vehicleId=v:getId();major443.charged=false end
  if major443.charged then return end
  local estimate=hud41Damage()
  if (estimate.estimateHigh or 0)>=1000 then
    major443.charged=true
    state.trust=clamp(state.trust-5,0,100)
    persist()
    major443.lastMessage=string.format('MAJOR DAMAGE: -5 TRUST | estimate up to £%d | trust %d/100',estimate.estimateHigh,state.trust)
    announce(major443.lastMessage)
  end
end
-- Explicit fresh career: never erase saved vehicles or liveries.
function M.resetCareer443(confirm)
  if confirm~='RESET' then return false,'pass RESET to confirm fresh career' end
  if live.active or race40.active or pitRepair432.busy or pitRepair432.rearmPending or pendingSwitch then
    return false,'stop timing, racing and vehicle operations before reset'
  end
  state.tier='f4';state.trust=60;state.funds=20000;state.points=0;state.races=0
  championship={season=1,round=1,phase='idle',tier='f4',team='Independent',results={},standings={},sponsor=0}
  sponsor44={active='none',paidRaces=0,lastBonus=0}
  live.laps=0;live.best=nil;live.last=0;live.elapsed=0;live.cleanStreak=0;live.gate=nil;live.lapEarnings=0;live.lastLapReward=nil;live.lastLapTime=nil
  race40.result=nil;race40.field=nil;race40.completed=false;race40.startElapsed=nil
  wing44.confirmed=false;wing44.vehicleId=nil
  major443.charged=false;major443.vehicleId=nil;major443.lastMessage='No major crash recorded'
  bridge.hudDamage={};bridge.componentDamage={};bridge.samples=0
  pitRepair432.lastCost=0;pitRepair432.lastMessage='No repairs yet';pitRepair432.lastRepairedEpoch=-1;pitRepair432.repairedVehicle=nil
  local a,b,c=persist(),saveWeekend(),sponsorSave44()
  announce('NEW CAREER: F4 | Funds £20000 | Trust 60 | Points 0 | Standings cleared. Saved cars preserved.')
  M.refreshDashboard()
  return a and b,'career reset'
end
function M.getDashboardState()
  local elapsed=live.elapsed or 0
  local running=live.active and live.last and live.last>0
  local lapTime=running and math.max(0,elapsed-live.last) or 0
  local result=race40.result
  local raceTime=(race40.startElapsed and live.elapsed-race40.startElapsed) or 0
  return {
    version='4.4.4-lap-rewards',tier=state.tier,team=championship.team,season=championship.season,
    round=championship.round,roundCount=#raceNames,track=raceNames[((championship.round-1)%#raceNames)+1],
    phase=championship.phase,trust=state.trust,funds=state.funds,points=state.points,
    practiceBest=championship.practice,qualifyingBest=championship.qualifying,grid=championship.grid,
    live={active=live.active,session=live.session,laps=live.laps,best=live.best,
      currentLap=lapTime,clockStarted=running and true or false,cleanStreak=live.cleanStreak or 0,lapEarnings=live.lapEarnings or 0,lastLapReward=live.lastLapReward,lastLapTime=live.lastLapTime},
    race={active=race40.active,target=race40.target,laps=live.laps,elapsed=math.max(0,raceTime),
      lastResult=result and {position=result.position,dnf=result.dnf,elapsed=result.elapsed,laps=result.laps} or nil},
    damage=hud41Damage(),lastMajorIncident=major443.lastMessage,sponsor={active=sponsor44.active,name=sponsorOffers44[sponsor44.active].name,lastBonus=sponsor44.lastBonus,offers=sponsorOffers44},pitRepair={busy=pitRepair432.busy or pitRepair432.rearmPending,lastCost=pitRepair432.lastCost,lastMessage=pitRepair432.lastMessage,towAvailable=homeSpawn45~=nil},standings=hud41Standings(), gateSet=live.gate~=nil, seriesAvailable={f4=vehicleBindings.f4 and vehicleBindings.f4.appearance~=nil or false,f3=vehicleBindings.f3 and vehicleBindings.f3.appearance~=nil or false,f2=vehicleBindings.f2 and vehicleBindings.f2.appearance~=nil or false,f1=vehicleBindings.f1 and vehicleBindings.f1.appearance~=nil or false},
    aiMode='Simulated lap times (no physical AI vehicles)'
  }
end
function M.refreshDashboard()
  if guihooks and type(guihooks.trigger)=='function' then
    guihooks.trigger('RoadToF1Dashboard',M.getDashboardState())
    return true
  end
  return false
end
-- 4.2: whitelist-only dashboard command bridge. No arbitrary Lua from the UI.
-- Loading another series car does not change the driver's contracted career tier.
function M.dashboardCommand(action, argument)
  local ok, result, detail
  if action == 'gate' then
    ok, result = M.setTimingGate(8)
  elseif action == 'startTiming' then
    ok, result = M.startLiveSession()
  elseif action == 'stopTiming' then
    ok, result = M.stopLiveSession()
  elseif action == 'submitTiming' then
    ok, result = M.submitLiveSession()
  elseif action == 'startWeekend' then
    ok, result = M.startWeekend()
  elseif action == 'startRace' then
    ok, result = M.startMeasuredRace()
  elseif action == 'raceDistance' then
    ok, result = M.setRaceDistance(tonumber(argument))
  elseif action == 'loadSeries' then
    if argument ~= 'f4' and argument ~= 'f3' and argument ~= 'f2' and argument ~= 'f1' then
      ok, result = false, 'invalid series'
    elseif live.active or race40.active then
      ok, result = false, 'stop active timing/race session before switching cars'
    elseif pendingSwitch then
      ok, result = false, 'vehicle switch already in progress'
    else
      ok, result = M.loadCareerVehicle(argument)
    end
  elseif action == 'wingDetached' then
    ok, result = M.confirmWingDetached()
  elseif action == 'chooseSponsor' then
    ok, result = M.chooseSponsor(argument)
  elseif action == 'pitRepair' then
    ok, result = M.pitRepair()
  elseif action == 'towToPits' then
    ok, result = M.towToPits()
  elseif action == 'resetCareer' then
    ok, result = M.resetCareer443(argument)
  elseif action == 'previewSeries' then
    ok, result = M.previewCareerSwitch(argument)
  elseif action == 'refresh' then
    ok, result = M.refreshDashboard(), nil
  else
    ok, result = false, 'unknown dashboard action'
  end
  if not ok then
    announce('Dashboard: '..tostring(result or 'command failed'))
  end
  if guihooks and type(guihooks.trigger)=='function' then
    guihooks.trigger('RoadToF1CommandResult', {action=tostring(action), ok=ok and true or false, detail=tostring(result or (ok and 'completed' or 'failed'))})
  end
  M.refreshDashboard()
  return (ok and 'OK' or 'ERROR')..': '..tostring(result or action)
end

-- 4.3: refresh after the map and vehicle are ready; don't assume UI exists at extension load.
local startup43={pending=true, elapsed=0, attempts=0}
local function armStartup43()
  startup43.pending=true
  startup43.elapsed=0
  startup43.attempts=0
end
function M.onClientStartMission() armStartup43() end
local hud41PreviousUpdate=M.onUpdate
function M.onUpdate(dtReal,dtSim,dtRaw)
  if hud41PreviousUpdate then hud41PreviousUpdate(dtReal,dtSim,dtRaw) end
  local dt=math.max(0,math.min(0.2,tonumber(dtReal) or 0))
  if startup43.pending then
    if playerVehicle() then
      startup43.elapsed=startup43.elapsed+dt
      if startup43.elapsed>=3 then
        startup43.elapsed=0
        startup43.attempts=startup43.attempts+1
        M.refreshDashboard()
        if startup43.attempts>=5 then
          startup43.pending=false
          announce('Dashboard startup refresh attempts complete')
        end
      end
    else
      startup43.elapsed=0
    end
  end
  hud41Clock=hud41Clock+dt
  if hud41Clock>=0.25 then
    hud41Clock=0
    M.refreshDashboard()
  end
end

return M

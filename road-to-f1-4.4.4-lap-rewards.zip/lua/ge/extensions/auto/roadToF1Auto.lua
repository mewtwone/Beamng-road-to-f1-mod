-- Auto-start Road to F1 when GE auto extensions are initialized.
-- Does not start race weekends, spawn vehicles or charge repair costs.
local M = {}
local function ensureLoaded()
  if not extensions.roadToF1 then
    extensions.load('roadToF1')
  end
end
function M.onExtensionLoaded() ensureLoaded() end
function M.onClientStartMission() ensureLoaded() end
return M

ROAD TO F1 2.0 - EXPERIMENTAL CAREER FOUNDATION

Install: close BeamNG.drive; back up settings/roadToF1Career.json and
settings/roadToF1Vehicles.json; remove the 1.0 ZIP from active mods;
place this ZIP in the active BeamNG.drive/current/mods folder.

GE Lua console:
extensions.load('roadToF1')
extensions.roadToF1.showStatus()
extensions.roadToF1.previewCareerSwitch('f2')
extensions.roadToF1.loadCareerVehicle('f2')
extensions.roadToF1.verifyCareerLivery('f2')

Weekend testing (simulated AI classification, not on-track racing):
extensions.roadToF1.chooseTeam('Apex')
extensions.roadToF1.startWeekend()
extensions.roadToF1.completePractice(95.5)
extensions.roadToF1.completeQualifying(94.8)
extensions.roadToF1.completeRace(5, 'clean')
extensions.roadToF1.showStandings()

IMPORTANT: completeRace(position) is a MANUAL result-entry command. Do not
use it to claim a real AI race occurred. No actual AI cars, race timing,
track enforcement or automated race results are implemented here.

Career state: settings/roadToF1Career.json (existing)
Vehicle bindings: settings/roadToF1Vehicles.json (existing)
Weekend progress: settings/roadToF1Weekend.json (new)

Damage telemetry remains diagnostic only; automatic billing is disabled.
If the vehicle restore fails, revert to 1.0 and restore backed-up saves.

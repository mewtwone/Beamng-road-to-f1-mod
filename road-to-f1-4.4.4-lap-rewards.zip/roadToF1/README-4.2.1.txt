Road to F1 4.2.1 dashboard hotfix. Replace 4.2 ZIP; preserve JSON saves. CSS now explicitly loaded. Commands use BeamNG engineScript and report results. Verify in-game; not yet runtime tested.

Prototype 0.8: save per-tier complete configuration identity, paints and nested chosen parts (Carbonworks presets / Genesis Ctrl+W). Captures only; automatic spawning/restoration is NOT implemented or tested. Back up saves before use.

Prototype 0.9: full livery snapshot and guarded manual restore.
Commands: extensions.roadToF1.previewSavedVehicle('f1')
          extensions.roadToF1.restoreSavedVehicle('f1')
Load matching Genesis vehicle before restore. Restoration depends on BeamNG setConfig API.
Save your current custom configuration in BeamNG first. No automatic spawning.

Road to F1 4.4.1
- Fix new damage not registering after pit repair: delayed Vehicle Lua damage bridge re-arm after respawn (including same vehicle ID).
- Clear previous damage and wing detachment only after successful respawn; do not double bill old damage.
- Reward £200 per completed 30-600s timed lap with no damage callbacks since lap start. Gate-based lap validation remains provisional (no track checkpoints).
- Repair stops active timing to prevent respawn-assisted lap rewards.
- Repair discount applies to body and suspension, wing replacement at full fixed price.
- Preserve career, sponsor and saved vehicle JSON files.
- Do not install multiple Road to F1 ZIP versions simultaneously.

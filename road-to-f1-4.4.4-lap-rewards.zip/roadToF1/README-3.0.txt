Road to F1 3.0 LIVE TIMING TEST

Uses player position and a manually calibrated start/finish gate; not a real track checkpoint system yet. Do not use for competitive lap validation.

GE Lua commands:
extensions.load("roadToF1")
extensions.roadToF1.startWeekend() (only if no weekend already active)
Drive to start/finish line and stop.
extensions.roadToF1.setTimingGate(8)
extensions.roadToF1.startLiveSession()
Drive out of gate, cross line to start clock, complete full laps.
extensions.roadToF1.liveTimingStatus()
extensions.roadToF1.stopLiveSession()
extensions.roadToF1.submitLiveSession() (practice/qualifying only)

No physical AI opponents or automatic race placement. Race phase can record timed laps but will not award points until race control is integrated. Career saves remain in existing JSON files.

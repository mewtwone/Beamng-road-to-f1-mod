Road to F1 4.2.3: Fix dashboard command transport from TorqueScript engineScript to GE Lua engineLua. Preserve existing saves. Remove prior ZIP before installing.

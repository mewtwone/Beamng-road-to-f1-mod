Road to F1 4.1 Dashboard

In BeamNG UI Apps > Add App, select Road to F1 Dashboard. Resize as desired.
Tabs: Timing, Standings, Damage.
Repair ranges are diagnostic estimates, never automatic charges.
The 4.0 gameplay commands remain unchanged.

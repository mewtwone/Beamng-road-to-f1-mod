Road to F1 4.3 STABILITY TEST (BeamNG 0.39 / DX11 evaluation)
- Dashboard refresh retries after player vehicle is available.
- Dashboard load-car button disabled after reported native/GPU crashes.
- GE Lua commands use a single expression without callback wrapping.
- Existing timing, damage estimates and career saves retained.
- Not yet validated in game. Keep one Road to F1 ZIP installed.

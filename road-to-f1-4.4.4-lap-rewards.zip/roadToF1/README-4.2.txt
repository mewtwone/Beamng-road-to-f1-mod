Road to F1 4.2 Dashboard Controls
Buttons: set timing gate, start/stop/submit timing, start weekend, race distance/start race, preview/load saved F4/F3/F2/F1 car.
Series car loading does not alter career tier or championship progress.
Requires BeamNG UI Apps -> Road to F1 Dashboard. No automatic damage charges.

Road to F1 3.1 - automatic initialization and damage diagnostics

Auto bootstrap: lua/ge/extensions/auto/roadToF1Auto.lua (requires BeamNG to load auto extensions).
Career extension auto-arms vehicle damage callback when player vehicle is ready.
Vehicle replacements automatically rearm telemetry after restore.
No repair charges or trust deductions from auto damage telemetry.
Verify in GE Lua: extensions.roadToF1.autoDamageStatus()
If extension is unavailable after loading map, run extensions.load('roadToF1') and report logs; auto bootstrap behavior is unverified on BeamNG 0.36.
Use only this ZIP; remove previous Road to F1 ZIPs from active mods.

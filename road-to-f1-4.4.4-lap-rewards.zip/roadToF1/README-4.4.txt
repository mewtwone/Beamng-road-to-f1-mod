Road to F1 4.4 - Component estimates and sponsor contracts

New: confirm detached front wing button, fixed replacement price F4/F3 1000, F2 10000, F1 20000.
This is a manual confirmation, NOT automatic wing detection. Wing costs are estimates until a pit repair is confirmed.
New: wheel/suspension-related damageTracker signals contribute a provisional suspension estimate.
No signal does not prove suspension is undamaged; body damage cannot reliably diagnose snapped suspension.
Pit repair discounts only body and suspension estimates; wing replacement is a fixed price.
New: Local Garage / TrackTech / Velocity sponsor contracts, with per-race bonuses and independent sponsor save.
Sponsor payments are applied after successful race result once; no bonus for DNF.
Sponsor selection is allowed between weekends only.
Existing career saves are unchanged. Sponsor data: settings/roadToF1Sponsors.json.
Existing vehicle-load button retained. DX11 game testing required.

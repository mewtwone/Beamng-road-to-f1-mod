Road to F1 4.3.2 — Pit repair experiment

Pit repair is manually confirmed; no automatic pit-lane geofencing.
Discount range: lower 37.5% of the current body-damage estimate.
One charge per new damage episode; repair respawns the currently selected configuration.
Do not use during active racing until validated. Vehicle loading is experimental and has previously caused native crashes.
Back up settings/roadToF1Career.json and settings/roadToF1Vehicles.json before installation.

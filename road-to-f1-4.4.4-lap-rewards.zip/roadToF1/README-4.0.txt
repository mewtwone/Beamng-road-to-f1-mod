Road to F1 4.0: real player lap timing vs 19 simulated AI finish times.
Commands: setRaceDistance(5), startMeasuredRace(), race40Status(), retireMeasuredRace("crash").
Requires career race phase and timing gate. No physical AI, checkpoints, automated crash DNF or financial charges.
Existing save files are not deleted. Backup saves before installing.

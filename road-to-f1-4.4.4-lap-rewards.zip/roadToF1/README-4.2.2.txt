4.2.2: Inject bngApi Angular service, use engineScript callback for command acknowledgement, and replace native series select with in-app button picker. Untested in BeamNG.

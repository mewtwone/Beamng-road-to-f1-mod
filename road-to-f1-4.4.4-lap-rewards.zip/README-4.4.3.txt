Road to F1 4.4.3 — Career Balance

- Every valid timed lap (30 to 600 seconds) earns £200, including laps with damage and F4 laps under 60 seconds.
- A five-lap streak without new reported damage earns +2 team trust. The streak resets when a lap has new damage, after repairs, or when a timing session restarts.
- An upper repair estimate of at least £1000 causes a one-time -5 team trust penalty for that incident. This is based on provisional damage estimates and may require calibration.
- The dashboard displays lap payouts and the clean-lap streak.
- Reset career to defaults through the two-step dashboard confirmation, or run extensions.roadToF1.resetCareer443('RESET') in GE Lua.
- Reset returns to F4, £20000 funds, 60 trust, zero points/races, season 1, round 1, empty standings, Independent team, and no sponsor. Saved vehicle profiles and liveries are preserved.
- Reset is NOT automatic on installation; deliberately confirm it in-game after backing up settings/roadToF1*.json.

In-game behavior has not been verified.
